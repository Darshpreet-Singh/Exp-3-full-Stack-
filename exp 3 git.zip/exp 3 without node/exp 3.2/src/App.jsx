import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import "./App.css";
import profilepic from "./assets/dps.jpeg";

/* ---------------- TOP BAR ---------------- */
function TopBar() {
  return (
    <div className="top-bar">
      <p>My React Portfolio</p>
    </div>
  );
}

/* ---------------- HEADER ---------------- */
function Header() {
  return (
    <header className="header">
      <Link to="/" className="app-name">HOME</Link>

      <nav className="nav-links">
        <Link to="/" className="nav-btn">Profile</Link>
        <Link to="/dashboard" className="nav-btn">Dashboard</Link>
      </nav>
    </header>
  );
}

/* ---------------- PROFILE PAGE ---------------- */
function Profile() {
  return (
    <>
      <h1>PROFILE PAGE</h1>
      <img src={profilepic} alt="Profile" width="200" />

      <h2>Projects</h2>
      <ol>
        <li>Disease Prediction Model</li>
        <li>Weather Prediction Model</li>
        <li>Antivirus Software</li>
      </ol>
    </>
  );
}

/* ---------------- DASHBOARD PAGE ---------------- */
function Dashboard() {
  return (
    <>
      <h1>DASHBOARD</h1>

      <h3>Skills</h3>
      <ol>
        <li>C++</li>
        <li>Python</li>
        <li>Designing</li>
        <li>Video Editing</li>
      </ol>

      <h3>Achievements</h3>
    </>
  );
}

/* ---------------- MAIN APP ---------------- */
function App() {
  return (
    <BrowserRouter>
      <TopBar />
      <Header />

      <Routes>
        <Route path="/" element={<Profile />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
