import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import profilepic from "./assets/dps.jpeg"

function Pofile() {
  return (
  <><h1>PROFILE PAGE</h1>;
  <img src={profilepic}  />

      <h2>Projects</h2>
      <ol>
        <li>DISEASE PREDICTION MODEL</li>
        <li>WEATHER PREDICTION MODEL</li>
        <li>ANTIVIRUS SOFTWARE</li>
      </ol>
    </>
  );
}
function Dashboard() {
  return( 
  <>
  <h1>DASHBOARD</h1>;
  <h3>SKILLS  </h3>
  <ol>
    <li>C++</li>
    <li>PYTHON</li>
    <li> DESIGNING</li>
    <li>VIDEO EDITING</li>
  </ol>
  <h3>ACHIEVEMENTS</h3>
  </>
  )
}


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Pofile />} />
        <Route path="/Dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;